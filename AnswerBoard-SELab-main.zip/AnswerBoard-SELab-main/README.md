\*\* NOTE - Make sure to have your own firebase API keys to access the database if you are running it on your local machine

1. Download the zip for se-project-code to run it on your local machine.
2. Goto se-project-code folder and run npm install on command line
3. run npm start to start the server
