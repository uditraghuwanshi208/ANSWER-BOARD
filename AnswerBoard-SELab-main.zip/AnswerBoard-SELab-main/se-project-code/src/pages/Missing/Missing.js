import React from 'react';

function Missing() {
    return (
        <>
            <p>Invalid address : 404</p>
        </>
    );
}

export default Missing;